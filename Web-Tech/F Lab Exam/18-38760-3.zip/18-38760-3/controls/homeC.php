<?php

    include("../models/db.php");

    // $connection = new db();
    // $connObj = $connection->openConn();

?>