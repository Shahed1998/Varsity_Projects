<script src="./../public/scripts/script.js?v=<?= time() ?>"></script>
</body>
</html>