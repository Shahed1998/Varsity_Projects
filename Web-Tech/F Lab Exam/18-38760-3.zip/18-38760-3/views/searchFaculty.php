<?php

    include('../../controls/staff/searchFac-controller.php');

    $output =  $userQuery;
    echo $output;

?>